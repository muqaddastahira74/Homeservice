const addCardBtn = document.querySelector(".add-btn");

if(addCardBtn){

    addCardBtn.addEventListener("click",()=>{

        alert("Add New Payment Method");

    });

}