
const categories = document.querySelectorAll(".category");
const cards = document.querySelectorAll(".service-card");

categories.forEach(category => {

category.addEventListener("click", () => {

document.querySelector(".active")?.classList.remove("active");
category.classList.add("active");

let selected = category.dataset.category;

cards.forEach(card => {

if(selected === "all"){

card.style.display = "block";

}

else if(card.classList.contains(selected)){

card.style.display = "block";

}

else{

card.style.display = "none";

}

});

});

});



const cards = document.querySelectorAll(".card");

cards.forEach(card=>{

card.addEventListener("click",()=>{

const role = card.dataset.role;

window.location.href = `signup.html?role=${role}`;

});

});


const form=document.getElementById("resetForm");

form.addEventListener("submit",function(e){

e.preventDefault();

let email=document.getElementById("email").value;

let password=document.getElementById("password").value;

let confirm=document.getElementById("confirm").value;

if(password!==confirm){

alert("Passwords do not match.");

return;

}

if(password.length<6){

alert("Password must be at least 6 characters.");

return;

}

alert("Password Changed Successfully!");

window.location.href="login.html";

});